/**
 * ============================================================
 *  MA PAGE DE VENTE · Kit IZI VIZI · Formation Claude
 * ============================================================
 *  Ce que ça fait :
 *   - affiche tes offres (lues dans l'onglet "Offres")
 *   - ton client choisit, remplit ses infos
 *   - un QR code de virement s'affiche avec le BON montant
 *   - la réservation arrive dans l'onglet "Réservations"
 *   - (option) un mail part chez toi et chez ton client
 *
 *  Installation (5 min) :
 *   1. Crée une Google Sheet vide
 *   2. Extensions > Apps Script
 *   3. Colle ce fichier dans "Code.gs" (remplace tout)
 *   4. Clique + > HTML, nomme-le "Page" et colle le fichier Page.html
 *   5. Choisis la fonction "installer" en haut, clique Exécuter, autorise
 *   6. Remplis les onglets "Réglages" et "Offres" dans ta Sheet
 *   7. Déployer > Nouveau déploiement > Application Web
 *      Exécuter en tant que : Moi · Accès : Tout le monde
 *   8. Copie l'URL : c'est ta page de vente !
 * ============================================================
 */

var ONGLET_REGLAGES = 'Réglages';
var ONGLET_OFFRES = 'Offres';
var ONGLET_RESA = 'Réservations';

/* ---------- 1. INSTALLATION (à lancer une seule fois) ---------- */
function installer() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var reg = ss.getSheetByName(ONGLET_REGLAGES) || ss.insertSheet(ONGLET_REGLAGES);
  if (reg.getLastRow() < 2) {
    reg.getRange(1, 1, 1, 3).setValues([['Réglage', 'Ta valeur', 'Explication']]);
    reg.getRange(2, 1, 11, 3).setValues([
      ['Nom de ton business', 'Mon Business', 'Le titre en haut de ta page'],
      ['Phrase d\'accroche', 'Réserve ta place en 2 minutes, paiement par QR code.', 'Sous le titre'],
      ['Nom du bénéficiaire', 'Prénom Nom', 'Le nom EXACT sur ton compte bancaire'],
      ['IBAN', 'BE00 0000 0000 0000', 'Ton numéro de compte (avec ou sans espaces)'],
      ['TVA (%)', 21, 'Mets 0 si tu es en franchise de TVA'],
      ['Email de notification', '', 'Tu reçois un mail à chaque réservation (laisse vide pour non)'],
      ['Mail de confirmation au client', 'Oui', 'Oui ou Non'],
      ['Préfixe des références', 'RESA', 'Ex : IZI donne IZI-0001, IZI-0002...'],
      ['Couleur principale', '#e7b142', 'Code couleur de ta marque'],
      ['Texte des conditions', 'J\'accepte les conditions générales de vente. Toute inscription payée est définitive.', 'La case à cocher avant de réserver'],
      ['Message après réservation', 'Merci ! Ta place est réservée dès réception du virement. À très vite 💛', 'Affiché au-dessus du QR code']
    ]);
    reg.getRange('A1:C1').setFontWeight('bold').setBackground('#f3f3f3');
    reg.setColumnWidth(1, 230); reg.setColumnWidth(2, 360); reg.setColumnWidth(3, 380);
    reg.setFrozenRows(1);
  }

  var off = ss.getSheetByName(ONGLET_OFFRES) || ss.insertSheet(ONGLET_OFFRES);
  if (off.getLastRow() < 2) {
    off.getRange(1, 1, 1, 7).setValues([['Actif', 'Offre', 'Description', 'Prix HTVA (€)', 'Infos (dates, durée...)', 'Texte du bouton', 'Code (pour un lien direct)']]);
    off.getRange(2, 1, 3, 7).setValues([
      ['Oui', 'Atelier découverte', '2h pour découvrir la méthode, en petit groupe.', 49, 'Samedi 14 nov · 10h-12h', 'Je réserve', 'atelier'],
      ['Oui', 'Coaching 1:1', 'Une séance rien que pour toi, sur ton projet.', 90, '1h · en visio ou sur place', 'Je réserve', 'coaching'],
      ['Non', 'Offre cachée', 'Mets "Non" dans Actif pour cacher une offre sans l\'effacer.', 120, '', 'Je réserve', 'cachee']
    ]);
    off.getRange('A1:G1').setFontWeight('bold').setBackground('#f3f3f3');
    off.getRange('A2:A50').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['Oui', 'Non']).build());
    off.setColumnWidth(2, 200); off.setColumnWidth(3, 340); off.setColumnWidth(5, 220);
    off.setFrozenRows(1);
  }

  var res = ss.getSheetByName(ONGLET_RESA) || ss.insertSheet(ONGLET_RESA);
  if (res.getLastRow() < 1) {
    res.getRange(1, 1, 1, 12).setValues([['Date', 'Référence', 'Offre', 'Infos', 'Prénom', 'Nom', 'Email', 'Téléphone', 'Message', 'Montant HTVA', 'À payer (TVAC)', 'Payé ?']]);
    res.getRange('A1:L1').setFontWeight('bold').setBackground('#f3f3f3');
    res.setFrozenRows(1);
  }

  var defaut = ss.getSheetByName('Feuille 1') || ss.getSheetByName('Sheet1');
  if (defaut && defaut.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(defaut);
  ss.setActiveSheet(reg);
  SpreadsheetApp.getUi && SpreadsheetApp.getActive().toast('C\'est installé ! Remplis maintenant "Réglages" et "Offres".', 'Ma page de vente', 8);
}

/* ---------- 2. LA PAGE ---------- */
function doGet(e) {
  var data = lireDonnees_();
  var t = HtmlService.createTemplateFromFile('Page');
  t.dataJson = JSON.stringify(data);
  t.offreDemandee = (e && e.parameter && e.parameter.offre) ? String(e.parameter.offre) : '';
  return t.evaluate()
    .setTitle(data.reglages.nom || 'Ma page de vente')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function lireDonnees_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var r = ss.getSheetByName(ONGLET_REGLAGES).getDataRange().getValues();
  var map = {};
  r.slice(1).forEach(function (l) { map[String(l[0]).trim()] = l[1]; });
  var tva = Number(map['TVA (%)']) || 0;
  var offres = ss.getSheetByName(ONGLET_OFFRES).getDataRange().getValues().slice(1)
    .filter(function (l) { return String(l[0]).trim().toLowerCase() === 'oui' && l[1]; })
    .map(function (l, i) {
      var htva = Number(l[3]) || 0;
      return {
        id: String(l[6] || ('offre' + (i + 1))).trim(),
        nom: String(l[1]),
        description: String(l[2] || ''),
        htva: htva,
        ttc: arrondi_(htva * (1 + tva / 100)),
        infos: String(l[4] || ''),
        bouton: String(l[5] || 'Je réserve')
      };
    });
  return {
    reglages: {
      nom: map['Nom de ton business'] || '',
      accroche: map['Phrase d\'accroche'] || '',
      tva: tva,
      couleur: map['Couleur principale'] || '#e7b142',
      conditions: map['Texte des conditions'] || '',
      merci: map['Message après réservation'] || ''
    },
    offres: offres
  };
}

/* ---------- 3. QUAND QUELQU'UN RÉSERVE ---------- */
function reserver(form) {
  if (!form || !form.offreId || !form.prenom || !form.email) throw new Error('Il manque une info : offre, prénom ou email.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(form.email))) throw new Error('Ton adresse email a l\'air incorrecte.');

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var r = ss.getSheetByName(ONGLET_REGLAGES).getDataRange().getValues();
  var reg = {};
  r.slice(1).forEach(function (l) { reg[String(l[0]).trim()] = l[1]; });

  var data = lireDonnees_();
  var offre = data.offres.filter(function (o) { return o.id === form.offreId; })[0];
  if (!offre) throw new Error('Cette offre n\'est plus disponible.');

  var iban = String(reg['IBAN'] || '').replace(/\s+/g, '').toUpperCase();
  var benef = String(reg['Nom du bénéficiaire'] || '').trim();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{8,30}$/.test(iban) || /^BE0+$/.test(iban)) throw new Error('Le paiement n\'est pas encore configuré (IBAN manquant).');

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  var ref;
  try {
    var resa = ss.getSheetByName(ONGLET_RESA);
    // On compte les lignes réellement remplies en colonne A (en-tête compris) :
    // c'est l'index de la prochaine référence, sans se laisser tromper par des cases à cocher vides.
    var n = resa.getRange('A:A').getValues().filter(String).length;
    ref = String(reg['Préfixe des références'] || 'RESA').trim().toUpperCase() + '-' + ('0000' + n).slice(-4);
    resa.appendRow([
      new Date(), ref, offre.nom, offre.infos,
      nettoie_(form.prenom), nettoie_(form.nom), nettoie_(form.email), nettoie_(form.tel), nettoie_(form.message),
      offre.htva, offre.ttc, false
    ]);
    // Case à cocher « Payé ? » ajoutée uniquement sur la nouvelle ligne.
    resa.getRange(resa.getLastRow(), 12).insertCheckboxes();
  } finally {
    lock.releaseLock();
  }

  var communication = (ref + ' ' + offre.nom + ' ' + form.prenom).substring(0, 140);
  var payload = qrEpc_(benef, iban, offre.ttc, communication);

  // mails (optionnels)
  var mailPro = String(reg['Email de notification'] || '').trim();
  try {
    if (mailPro) {
      MailApp.sendEmail(mailPro, 'Nouvelle réservation ' + ref + ' : ' + offre.nom,
        offre.nom + (offre.infos ? ' (' + offre.infos + ')' : '') + '\n' +
        'Client : ' + form.prenom + ' ' + (form.nom || '') + ' · ' + form.email + (form.tel ? ' · ' + form.tel : '') + '\n' +
        'Montant attendu : ' + euros_(offre.ttc) + '\nRéférence : ' + ref + (form.message ? '\nMessage : ' + form.message : ''));
    }
    if (String(reg['Mail de confirmation au client'] || '').toLowerCase() === 'oui') {
      MailApp.sendEmail(String(form.email), 'Ta réservation ' + ref + ' : ' + offre.nom,
        'Hello ' + form.prenom + ',\n\nMerci pour ta réservation : ' + offre.nom + (offre.infos ? ' (' + offre.infos + ')' : '') + '.\n\n' +
        'Pour la confirmer, fais un virement de ' + euros_(offre.ttc) + '\n' +
        'Bénéficiaire : ' + benef + '\nIBAN : ' + formatIban_(iban) + '\nCommunication : ' + communication + '\n\n' +
        'À très vite,\n' + (reg['Nom de ton business'] || benef));
    }
  } catch (err) { /* le mail n'est pas bloquant */ }

  return {
    ref: ref,
    offre: offre.nom,
    montant: offre.ttc,
    montantTexte: euros_(offre.ttc),
    beneficiaire: benef,
    iban: formatIban_(iban),
    communication: communication,
    payload: payload,
    merci: String(reg['Message après réservation'] || '')
  };
}

/* ---------- OUTILS ---------- */
// QR code de virement européen (standard EPC / "GiroCode"), lu par les apps bancaires
function qrEpc_(nom, iban, montant, communication) {
  return [
    'BCD', '002', '1', 'SCT', '',
    sansAccents_(nom).substring(0, 70),
    iban,
    'EUR' + Number(montant).toFixed(2),
    '', '',
    sansAccents_(communication).substring(0, 140)
  ].join('\n');
}
function sansAccents_(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7E]/g, ''); }
function arrondi_(x) { return Math.round(x * 100) / 100; }
function euros_(x) { return Number(x).toFixed(2).replace('.', ',') + ' €'; }
function formatIban_(i) { return i.replace(/(.{4})/g, '$1 ').trim(); }
function nettoie_(s) { s = String(s || '').trim().substring(0, 500); return /^[=+\-@]/.test(s) ? "'" + s : s; }
