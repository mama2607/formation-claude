# Crée ta page de vente · mode d'emploi

Ta page de vente toute prête : tes offres, un formulaire, un QR code de virement avec le bon montant, et chaque réservation qui arrive dans ta Google Sheet. Gratuit, sans site, sans plateforme de paiement.

## Installation (10 minutes)

1. Ouvre **sheets.new** pour créer une Google Sheet vide. Donne-lui un nom, par exemple "Ma page de vente".
2. Menu **Extensions > Apps Script**.
3. Dans **Code.gs**, efface tout et colle le contenu du fichier `Code.gs`.
4. Clique sur **+** à côté de "Fichiers", choisis **HTML**, nomme-le exactement **Page** puis colle le contenu de `Page.html`.
5. Clique sur la disquette pour enregistrer.
6. En haut, choisis la fonction **installer** et clique **Exécuter**. Google te demande l'autorisation : "Examiner les autorisations", choisis ton compte, puis "Paramètres avancés > Accéder au projet". (C'est ton propre script, c'est normal.)
7. Retourne dans ta Sheet : 3 onglets sont apparus.
   - **Réglages** : ton nom de business, ton IBAN, le nom exact du titulaire du compte, ta TVA (0 si tu es en franchise), ta couleur...
   - **Offres** : une ligne par offre. "Oui" dans Actif pour l'afficher, "Non" pour la cacher.
   - **Réservations** : ça se remplit tout seul.
8. Dans Apps Script : **Déployer > Nouveau déploiement**, roue dentée > **Application Web**.
   - Exécuter en tant que : **Moi**
   - Qui a accès : **Tout le monde**
   - Clique **Déployer** et copie l'**URL de l'application Web**. C'est ta page !

## Au quotidien

- Tu changes un prix ou une date dans l'onglet Offres : la page se met à jour toute seule.
- Une réservation arrive : une ligne s'ajoute, tu reçois un mail (si tu as mis ton email dans Réglages) et ton client reçoit les infos de paiement.
- Le virement arrive sur ton compte : tu coches **Payé ?** dans la ligne.
- Tu modifies le code (Code.gs ou Page) ? Il faut redéployer : **Déployer > Gérer les déploiements > crayon > Nouvelle version**. Le lien reste le même.

## Où mettre ton lien

- En bio Instagram
- Sur ton site, derrière un bouton "Réserver"
- En QR code imprimé au comptoir
- Lien direct vers une offre : ajoute `?offre=CODE` à la fin (le code se trouve dans la dernière colonne de l'onglet Offres). Exemple : `.../exec?offre=atelier`

## Demande à Claude de la personnaliser

Colle tes deux fichiers dans Claude et demande par exemple :

- "Change le style de Page.html pour qu'il colle à ma charte : [couleurs, polices, ambiance]."
- "Ajoute une section avec 3 avis clients et une FAQ sous les offres."
- "Réécris les descriptions de mes offres dans ma voix, en 2 phrases, avec ce que la cliente y gagne."
- "Ajoute un champ 'Taille de t-shirt' obligatoire seulement pour l'offre Merch, et enregistre-le dans la Sheet."
- "Ajoute un nombre de places par offre et affiche 'Complet' quand il n'en reste plus."

## Bon à savoir

- Le QR code suit le standard européen **EPC** (GiroCode) : il est lu par les apps des banques belges et européennes. Le client vérifie toujours avant de valider.
- Rien n'est encaissé automatiquement : c'est un virement classique, gratuit.
- Ton IBAN s'affiche sur la page de paiement, comme sur une facture.
- Respecte le RGPD : n'utilise les données que pour la réservation, et mentionne-le dans tes conditions.
